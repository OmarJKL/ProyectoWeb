package pe.utp.lambdashield.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;

import java.time.Instant;

/** Una operación evaluada por el motor de fraude (proviene de UTP Banca o del Simulador). */
@Entity
@Table(name = "registro_transaccion", indexes = {
        @Index(name = "idx_reg_cliente_origen_fecha", columnList = "cliente, origen, fecha")
})
public class RegistroTransaccion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(nullable = false)
    public Instant fecha;

    // --- Datos de la operación
    @Column(nullable = false, length = 40)  public String cliente;
    @Column(nullable = false, length = 120) public String clienteNombre;
    @Column(nullable = false)               public double monto;
    @Column(nullable = false, length = 30)  public String categoria;
    @Column(nullable = false)               public int hora;
    @Column(nullable = false, length = 20)  public String pais;
    @Column(nullable = false, length = 20)  public String dispositivo;
    @Column(nullable = false)               public int operacionesUltimaHora;
    @Column(nullable = false, length = 20)  public String beneficiario;
    @Column(nullable = false, length = 20)  public String ip;

    // --- Datos propios del canal (banca)
    @Column(nullable = false, length = 30)  public String origen;
    @Column(length = 120) public String cuentaOrigen;
    @Column(length = 160) public String destino;
    @Column(length = 80)  public String claveDestino;
    @Column(length = 200) public String concepto;

    // --- Señales reales medidas por el servidor
    @Column(length = 64) public String direccionIp;
    @Column(length = 32) public String huellaDispositivo;

    // --- Veredicto
    @Column(nullable = false) public int puntaje;
    @Column(nullable = false, length = 10) public String nivel;
    @Column(nullable = false) public boolean bloqueada;
    @Column(nullable = false, length = 8000) public String factoresJson;

    public RegistroTransaccion() {}
}
