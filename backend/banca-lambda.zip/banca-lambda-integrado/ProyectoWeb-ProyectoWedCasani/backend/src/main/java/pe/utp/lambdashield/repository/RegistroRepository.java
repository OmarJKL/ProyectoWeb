package pe.utp.lambdashield.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.utp.lambdashield.model.RegistroTransaccion;

import java.time.Instant;
import java.util.List;

public interface RegistroRepository extends JpaRepository<RegistroTransaccion, Long> {

    List<RegistroTransaccion> findAllByOrderByIdDesc();

    long countByClienteAndOrigenAndFechaAfter(String cliente, String origen, Instant desde);

    boolean existsByClienteAndOrigen(String cliente, String origen);

    boolean existsByClienteAndOrigenAndClaveDestino(String cliente, String origen, String claveDestino);

    boolean existsByClienteAndOrigenAndDireccionIp(String cliente, String origen, String direccionIp);

    boolean existsByClienteAndOrigenAndHuellaDispositivo(String cliente, String origen, String huellaDispositivo);
}
