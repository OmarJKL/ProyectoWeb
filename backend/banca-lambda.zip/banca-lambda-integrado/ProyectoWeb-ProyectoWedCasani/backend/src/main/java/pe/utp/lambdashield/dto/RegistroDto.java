package pe.utp.lambdashield.dto;

import pe.utp.lambdashield.motor.MotorFraude;

import java.time.Instant;

/** Misma forma que usaba el frontend en localStorage: { id, fecha, tr, veredicto }. */
public record RegistroDto(String id, Instant fecha, Tr tr, MotorFraude.Veredicto veredicto) {

    public record Tr(String cliente, String clienteNombre, double monto, String categoria, int hora,
                     String pais, String dispositivo, int operacionesUltimaHora, String beneficiario,
                     String ip, String origen, String cuentaOrigen, String destino, String claveDestino,
                     String concepto) {}
}
