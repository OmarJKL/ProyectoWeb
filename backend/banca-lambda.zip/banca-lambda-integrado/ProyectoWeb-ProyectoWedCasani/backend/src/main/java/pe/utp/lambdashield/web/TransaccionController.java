package pe.utp.lambdashield.web;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import pe.utp.lambdashield.dto.RegistroDto;
import pe.utp.lambdashield.dto.SimulacionRequest;
import pe.utp.lambdashield.dto.TransferenciaRequest;
import pe.utp.lambdashield.service.EvaluacionService;
import pe.utp.lambdashield.service.EventosService;

import java.util.List;

@RestController
@RequestMapping("/api")
public class TransaccionController {

    private final EvaluacionService evaluacion;
    private final EventosService eventos;

    public TransaccionController(EvaluacionService evaluacion, EventosService eventos) {
        this.evaluacion = evaluacion;
        this.eventos = eventos;
    }

    /** UTP Banca: evalúa y registra una transferencia antes de ejecutarla. */
    @PostMapping("/transferencias/evaluar")
    public RegistroDto evaluarTransferencia(@Valid @RequestBody TransferenciaRequest req, HttpServletRequest http) {
        return evaluacion.evaluarTransferencia(req, ipDe(http), http.getHeader("User-Agent"));
    }

    /** Simulador de Lambda Shield. */
    @PostMapping("/transacciones/simular")
    public RegistroDto simular(@Valid @RequestBody SimulacionRequest req, HttpServletRequest http) {
        return evaluacion.simular(req, ipDe(http));
    }

    /** Registro detallado (más reciente primero). */
    @GetMapping("/transacciones")
    public List<RegistroDto> listar() {
        return evaluacion.listar();
    }

    @DeleteMapping("/transacciones")
    public ResponseEntity<Void> reiniciar() {
        evaluacion.reiniciar();
        return ResponseEntity.noContent().build();
    }

    /** Flujo en vivo de registros nuevos (Server-Sent Events). */
    @GetMapping(value = "/transacciones/eventos", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter eventos() {
        return eventos.suscribir();
    }

    /** IP del cliente; las direcciones de loopback (IPv4/IPv6) se unifican para no marcar "IP nueva" en local. */
    private static String ipDe(HttpServletRequest http) {
        String ip = http.getRemoteAddr();
        if ("0:0:0:0:0:0:0:1".equals(ip) || "::1".equals(ip)) return "127.0.0.1";
        return ip;
    }
}
