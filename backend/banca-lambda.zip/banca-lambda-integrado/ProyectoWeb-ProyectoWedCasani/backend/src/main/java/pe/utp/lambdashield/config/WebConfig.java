package pe.utp.lambdashield.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.nio.file.Path;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    private final Path raiz;

    public WebConfig(@Value("${app.raiz-proyectos:../..}") String raiz) {
        this.raiz = Path.of(raiz).toAbsolutePath().normalize();
    }

    /** Sirve SOLO las carpetas de frontend (nunca backend/). */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/utp-banca/**")
                .addResourceLocations(raiz.resolve("utp-banca").toUri().toString());
        registry.addResourceHandler("/ProyectoWeb-ProyectoWedCasani/frontend/**")
                .addResourceLocations(raiz.resolve("ProyectoWeb-ProyectoWedCasani").resolve("frontend").toUri().toString());
    }

    /** Solo para desarrollo con otro servidor estático (p. ej. Live Server en :5500). */
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")
                .allowedOriginPatterns("http://localhost:*", "http://127.0.0.1:*")
                .allowedMethods("GET", "POST", "DELETE");
    }
}
