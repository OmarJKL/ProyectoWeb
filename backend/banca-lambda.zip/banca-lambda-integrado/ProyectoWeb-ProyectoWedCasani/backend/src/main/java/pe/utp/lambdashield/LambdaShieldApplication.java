package pe.utp.lambdashield;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LambdaShieldApplication {
    public static void main(String[] args) {
        SpringApplication.run(LambdaShieldApplication.class, args);
    }
}
