package pe.utp.lambdashield.web;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import java.nio.file.Path;

/** Atajos para abrir los dos frontends desde el mismo servidor (mismo origen, sin CORS). */
@Controller
public class FrontendController {

    private final Path raiz;

    public FrontendController(@Value("${app.raiz-proyectos:../..}") String raiz) {
        this.raiz = Path.of(raiz).toAbsolutePath().normalize();
    }

    @GetMapping({"/", "/utp-banca", "/utp-banca/"})
    public String bancaInicio() {
        return "redirect:/utp-banca/index.html";
    }

    @GetMapping({"/lambda-shield", "/lambda-shield/"})
    public String lambdaInicio() {
        return "redirect:/ProyectoWeb-ProyectoWedCasani/frontend/html/login.html";
    }

    /**
     * index.html de Lambda Shield está en la raíz del proyecto (junto a backend/), por eso se sirve
     * con un controlador y no con un handler de carpeta: así el código y la base de datos de backend/
     * nunca quedan expuestos por HTTP.
     */
    @GetMapping(value = "/ProyectoWeb-ProyectoWedCasani/index.html", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<Resource> indexLambda() {
        Resource r = new FileSystemResource(raiz.resolve("ProyectoWeb-ProyectoWedCasani").resolve("index.html"));
        if (!r.exists()) return ResponseEntity.notFound().build();
        return ResponseEntity.ok().contentType(MediaType.TEXT_HTML).body(r);
    }
}
