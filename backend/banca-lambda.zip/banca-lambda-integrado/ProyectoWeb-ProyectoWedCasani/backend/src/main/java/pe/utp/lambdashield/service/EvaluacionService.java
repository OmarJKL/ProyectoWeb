package pe.utp.lambdashield.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pe.utp.lambdashield.dto.RegistroDto;
import pe.utp.lambdashield.dto.SimulacionRequest;
import pe.utp.lambdashield.dto.TransferenciaRequest;
import pe.utp.lambdashield.model.RegistroTransaccion;
import pe.utp.lambdashield.motor.MotorFraude;
import pe.utp.lambdashield.repository.RegistroRepository;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;

@Service
public class EvaluacionService {

    static final String ORIGEN_BANCA = "UTP Banca";
    static final String ORIGEN_SIMULADOR = "Simulador";
    private static final ZoneId ZONA_LIMA = ZoneId.of("America/Lima");

    /** Promedio histórico de egresos por cliente de UTP Banca (los mismos datos base de la demo). */
    private static final Map<String, Double> PROMEDIO_BANCA = Map.of(
            "demo", (85.40 + 64.90) / 2,
            "maria", 59.90,
            "juan", 350.00);
    private static final double PROMEDIO_POR_DEFECTO = 100.0;

    private final MotorFraude motor = new MotorFraude();
    private final RegistroRepository repositorio;
    private final EventosService eventos;
    private final ObjectMapper json;

    public EvaluacionService(RegistroRepository repositorio, EventosService eventos, ObjectMapper json) {
        this.repositorio = repositorio;
        this.eventos = eventos;
        this.json = json;
    }

    /** Evalúa una transferencia de UTP Banca con señales reales del servidor y la registra. */
    @Transactional
    public RegistroDto evaluarTransferencia(TransferenciaRequest req, String ipCliente, String userAgent) {
        String cliente = req.usuario().trim().toLowerCase();
        Instant ahora = Instant.now();

        long previasUltimaHora = repositorio.countByClienteAndOrigenAndFechaAfter(
                cliente, ORIGEN_BANCA, ahora.minus(Duration.ofHours(1)));
        int operaciones = (int) Math.min(previasUltimaHora + 1, 20);

        boolean beneficiarioConocido = req.esDestinoPropio()
                || !req.esDestinoNuevo()
                || repositorio.existsByClienteAndOrigenAndClaveDestino(cliente, ORIGEN_BANCA, req.claveDestino());

        // IP y dispositivo (huella del User-Agent) reales; el primer uso del cliente es la línea base.
        String huella = huella(userAgent);
        boolean hayHistorial = repositorio.existsByClienteAndOrigen(cliente, ORIGEN_BANCA);
        boolean ipNueva = hayHistorial
                && !repositorio.existsByClienteAndOrigenAndDireccionIp(cliente, ORIGEN_BANCA, ipCliente);
        boolean dispositivoNuevo = hayHistorial
                && !repositorio.existsByClienteAndOrigenAndHuellaDispositivo(cliente, ORIGEN_BANCA, huella);

        String zona = req.zonaHoraria();
        String pais = (zona == null || zona.isBlank() || "America/Lima".equals(zona)) ? "local" : "regional";
        int hora = ZonedDateTime.ofInstant(ahora, ZONA_LIMA).getHour();

        // Modo demostración: simula señales que un navegador local no puede aportar.
        String modo = req.modoContexto() == null ? "normal" : req.modoContexto();
        if ("nuevo".equals(modo) || "extranjero".equals(modo)) {
            dispositivoNuevo = true;
            ipNueva = true;
        }
        if ("extranjero".equals(modo)) {
            pais = "alto_riesgo";
            hora = 3;
        }

        MotorFraude.Entrada entrada = new MotorFraude.Entrada(
                req.monto(), "transferencia", hora, pais,
                dispositivoNuevo ? "nuevo" : "reconocido",
                operaciones,
                beneficiarioConocido ? "recurrente" : "nuevo",
                ipNueva ? "nueva" : "conocida");

        MotorFraude.Veredicto veredicto = motor.evaluar(
                entrada, PROMEDIO_BANCA.getOrDefault(cliente, PROMEDIO_POR_DEFECTO));

        RegistroTransaccion r = nuevoRegistro(ahora, cliente, req.nombre(), entrada, veredicto, ORIGEN_BANCA);
        r.cuentaOrigen = req.cuentaOrigen();
        r.destino = req.destino();
        r.claveDestino = req.claveDestino();
        r.concepto = req.concepto() == null ? "" : req.concepto();
        r.direccionIp = ipCliente;
        r.huellaDispositivo = huella;
        return guardarYPublicar(r);
    }

    /** Evalúa una operación del Simulador de Lambda Shield. */
    @Transactional
    public RegistroDto simular(SimulacionRequest req, String ipCliente) {
        MotorFraude.Entrada entrada = new MotorFraude.Entrada(
                req.monto(), req.categoria(), req.hora(), req.pais(), req.dispositivo(),
                req.operacionesUltimaHora(), req.beneficiario(), req.ip());
        MotorFraude.Veredicto veredicto = motor.evaluar(entrada, req.promedioCliente());

        RegistroTransaccion r = nuevoRegistro(Instant.now(), req.cliente(), req.clienteNombre(),
                entrada, veredicto, ORIGEN_SIMULADOR);
        r.direccionIp = ipCliente;
        return guardarYPublicar(r);
    }

    @Transactional(readOnly = true)
    public List<RegistroDto> listar() {
        return repositorio.findAllByOrderByIdDesc().stream().map(this::aDto).toList();
    }

    @Transactional
    public void reiniciar() {
        repositorio.deleteAllInBatch();
        eventos.publicar("reset", Map.of("ok", true));
    }

    // ------------------------------------------------------------------ internos

    private RegistroTransaccion nuevoRegistro(Instant fecha, String cliente, String nombre,
                                              MotorFraude.Entrada e, MotorFraude.Veredicto v, String origen) {
        RegistroTransaccion r = new RegistroTransaccion();
        r.fecha = fecha;
        r.cliente = cliente;
        r.clienteNombre = nombre;
        r.monto = e.monto();
        r.categoria = e.categoria();
        r.hora = e.hora();
        r.pais = e.pais();
        r.dispositivo = e.dispositivo();
        r.operacionesUltimaHora = e.operacionesUltimaHora();
        r.beneficiario = e.beneficiario();
        r.ip = e.ip();
        r.origen = origen;
        r.puntaje = v.puntaje();
        r.nivel = v.nivel();
        r.bloqueada = v.bloqueada();
        try {
            r.factoresJson = json.writeValueAsString(v.factores());
        } catch (JsonProcessingException ex) {
            throw new IllegalStateException("No se pudo serializar el detalle del veredicto", ex);
        }
        return r;
    }

    private RegistroDto guardarYPublicar(RegistroTransaccion r) {
        RegistroDto dto = aDto(repositorio.save(r));
        eventos.publicar("registro", dto);
        return dto;
    }

    private RegistroDto aDto(RegistroTransaccion r) {
        List<MotorFraude.Factor> factores;
        try {
            factores = json.readValue(r.factoresJson, new TypeReference<List<MotorFraude.Factor>>() {});
        } catch (JsonProcessingException ex) {
            throw new IllegalStateException("Detalle de veredicto corrupto en el registro " + r.id, ex);
        }
        MotorFraude.Veredicto veredicto = new MotorFraude.Veredicto(
                r.puntaje, r.nivel, "critico".equals(r.nivel), "alto".equals(r.nivel), factores);
        RegistroDto.Tr tr = new RegistroDto.Tr(r.cliente, r.clienteNombre, r.monto, r.categoria, r.hora,
                r.pais, r.dispositivo, r.operacionesUltimaHora, r.beneficiario, r.ip, r.origen,
                r.cuentaOrigen, r.destino, r.claveDestino, r.concepto);
        return new RegistroDto(String.format("TR-%05d", r.id), r.fecha, tr, veredicto);
    }

    private static String huella(String userAgent) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256")
                    .digest((userAgent == null ? "" : userAgent).getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hash).substring(0, 16);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
