package pe.utp.lambdashield.dto;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

/** Lo que envía el Simulador de Lambda Shield. */
public record SimulacionRequest(
        @NotBlank @Size(max = 40) String cliente,
        @NotBlank @Size(max = 120) String clienteNombre,
        @Positive @DecimalMax("1000000") double monto,
        @NotBlank @Size(max = 30) String categoria,
        @Min(0) @Max(23) int hora,
        @NotBlank @Size(max = 20) String pais,
        @NotBlank @Size(max = 20) String dispositivo,
        @Min(1) @Max(20) int operacionesUltimaHora,
        @NotBlank @Size(max = 20) String beneficiario,
        @NotBlank @Size(max = 20) String ip,
        @Positive double promedioCliente) {}
