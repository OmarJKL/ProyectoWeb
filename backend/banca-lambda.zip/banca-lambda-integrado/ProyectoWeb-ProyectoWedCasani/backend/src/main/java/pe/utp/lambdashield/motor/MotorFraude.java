package pe.utp.lambdashield.motor;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Motor de reglas de fraude. Es la versión Java de frontend/js/motorFraude.js:
 * mismas 8 reglas, mismos pesos y mismos umbrales (bajo &lt; 30, medio &lt; 60, alto &lt; 80, crítico ≥ 80).
 * No depende de Spring, por lo que se puede probar de forma aislada.
 */
public final class MotorFraude {

    public record Entrada(double monto, String categoria, int hora, String pais, String dispositivo,
                          int operacionesUltimaHora, String beneficiario, String ip) {}

    public record Factor(String id, String etiqueta, int puntaje, int max, String motivo) {}

    public record Veredicto(int puntaje, String nivel, boolean bloqueada, boolean enRevision, List<Factor> factores) {}

    private static final int UMBRAL_BAJO = 30;
    private static final int UMBRAL_MEDIO = 60;
    private static final int UMBRAL_ALTO = 80;

    public Veredicto evaluar(Entrada tr, double promedioCliente) {
        List<Factor> factores = new ArrayList<>();
        factores.add(reglaMonto(tr, promedioCliente));
        factores.add(reglaUbicacion(tr));
        factores.add(reglaHorario(tr));
        factores.add(reglaVelocidad(tr));
        factores.add(reglaDispositivo(tr));
        factores.add(reglaCategoria(tr));
        factores.add(reglaBeneficiario(tr));
        factores.add(reglaIp(tr));

        int total = Math.min(100, factores.stream().mapToInt(Factor::puntaje).sum());
        String nivel = nivelDePuntaje(total);
        return new Veredicto(total, nivel, "critico".equals(nivel), "alto".equals(nivel), List.copyOf(factores));
    }

    public static String nivelDePuntaje(int puntaje) {
        if (puntaje < UMBRAL_BAJO) return "bajo";
        if (puntaje < UMBRAL_MEDIO) return "medio";
        if (puntaje < UMBRAL_ALTO) return "alto";
        return "critico";
    }

    /** Interpola linealmente [minIn,maxIn] → [minOut,maxOut] con límite en los extremos. */
    static double escalar(double valor, double minIn, double maxIn, double minOut, double maxOut) {
        if (maxIn == minIn) return minOut;
        double t = (valor - minIn) / (maxIn - minIn);
        double limitado = Math.max(0, Math.min(1, t));
        return minOut + limitado * (maxOut - minOut);
    }

    // Igual que toFixed() de JavaScript: redondea el valor binario exacto del double.
    private static String f2(double v) { return new BigDecimal(v).setScale(2, RoundingMode.HALF_UP).toPlainString(); }
    private static String f1(double v) { return new BigDecimal(v).setScale(1, RoundingMode.HALF_UP).toPlainString(); }
    private static String hh(int hora) { return String.format(Locale.ROOT, "%02d", hora); }

    private Factor reglaMonto(Entrada tr, double promedioCliente) {
        final int max = 20;
        double promedio = promedioCliente > 0 ? promedioCliente : 100;
        double proporcion = tr.monto() / promedio;
        double puntaje;
        String motivo;
        if (proporcion <= 1.5) {
            puntaje = 0;
            motivo = "Monto S/ " + f2(tr.monto()) + " dentro del rango habitual (prom. S/ " + f2(promedio) + ").";
        } else if (proporcion <= 3) {
            puntaje = escalar(proporcion, 1.5, 3, 5, 12);
            motivo = "Monto " + f1(proporcion) + "x por encima del promedio del titular.";
        } else {
            puntaje = escalar(proporcion, 3, 8, 12, max);
            motivo = "Monto " + f1(proporcion) + "x por encima del promedio: fuerte desviación de patrón.";
        }
        return new Factor("monto", "Monto inusual", (int) Math.round(puntaje), max, motivo);
    }

    private Factor reglaUbicacion(Entrada tr) {
        final int max = 15;
        return switch (tr.pais() == null ? "" : tr.pais()) {
            case "regional" -> new Factor("ubicacion", "Ubicación geográfica", 8, max,
                    "Operación desde un país vecino no habitual para este titular.");
            case "alto_riesgo" -> new Factor("ubicacion", "Ubicación geográfica", max, max,
                    "Operación desde una jurisdicción marcada como de alto riesgo.");
            default -> new Factor("ubicacion", "Ubicación geográfica", 0, max,
                    "Operación realizada en el país habitual del titular.");
        };
    }

    private Factor reglaHorario(Entrada tr) {
        final int max = 10;
        int hora = tr.hora();
        int puntaje;
        String motivo;
        if (hora >= 0 && hora < 5) {
            puntaje = max;
            motivo = "Operación a las " + hh(hora) + ":00, en horario de madrugada (00:00–05:00).";
        } else if (hora >= 22) {
            puntaje = 4;
            motivo = "Operación nocturna (" + hh(hora) + ":00), fuera del horario típico.";
        } else {
            puntaje = 0;
            motivo = "Operación dentro del horario habitual de actividad.";
        }
        return new Factor("horario", "Horario de la operación", puntaje, max, motivo);
    }

    private Factor reglaVelocidad(Entrada tr) {
        final int max = 15;
        int n = tr.operacionesUltimaHora();
        double puntaje;
        String motivo;
        if (n <= 1) {
            puntaje = 0;
            motivo = "Frecuencia normal: una sola operación en la última hora.";
        } else if (n <= 3) {
            puntaje = escalar(n, 2, 3, 4, 8);
            motivo = n + " operaciones en la última hora: frecuencia algo elevada.";
        } else {
            puntaje = escalar(n, 4, 12, 8, max);
            motivo = n + " operaciones en la última hora: patrón típico de \"card testing\".";
        }
        return new Factor("velocidad", "Velocidad de transacciones", (int) Math.round(puntaje), max, motivo);
    }

    private Factor reglaDispositivo(Entrada tr) {
        final int max = 10;
        if ("nuevo".equals(tr.dispositivo())) {
            return new Factor("dispositivo", "Dispositivo / huella digital", max, max,
                    "Dispositivo sin historial previo para este titular.");
        }
        return new Factor("dispositivo", "Dispositivo / huella digital", 0, max,
                "Dispositivo reconocido y previamente asociado al titular.");
    }

    private Factor reglaCategoria(Entrada tr) {
        final int max = 10;
        if (Set.of("casino", "cripto").contains(String.valueOf(tr.categoria()))) {
            return new Factor("categoria", "Categoría de comercio", max, max,
                    "Rubro \"" + tr.categoria() + "\" clasificado como de alto riesgo.");
        }
        return new Factor("categoria", "Categoría de comercio", 0, max,
                "Rubro \"" + tr.categoria() + "\" sin riesgo elevado asociado.");
    }

    private Factor reglaBeneficiario(Entrada tr) {
        final int max = 10;
        if ("nuevo".equals(tr.beneficiario())) {
            return new Factor("beneficiario", "Tipo de beneficiario", max, max,
                    "Beneficiario nuevo o sin historial de transacciones previas.");
        }
        return new Factor("beneficiario", "Tipo de beneficiario", 0, max, "Beneficiario recurrente y validado.");
    }

    private Factor reglaIp(Entrada tr) {
        final int max = 10;
        if ("nueva".equals(tr.ip())) {
            return new Factor("ip", "Dirección IP", max, max,
                    "Conexión desde una dirección IP no registrada previamente.");
        }
        return new Factor("ip", "Dirección IP", 0, max, "Conexión desde una dirección IP habitual e histórica.");
    }
}
