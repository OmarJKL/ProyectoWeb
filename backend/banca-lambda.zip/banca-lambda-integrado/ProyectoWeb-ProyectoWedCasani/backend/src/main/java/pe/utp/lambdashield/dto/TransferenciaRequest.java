package pe.utp.lambdashield.dto;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

/** Lo que envía UTP Banca cuando el usuario confirma una transferencia. */
public record TransferenciaRequest(
        @NotBlank @Size(max = 40) String usuario,
        @NotBlank @Size(max = 120) String nombre,
        @Positive @DecimalMax("1000000") double monto,
        @NotBlank @Size(max = 120) String cuentaOrigen,
        @NotBlank @Size(max = 160) String destino,
        @NotBlank @Size(max = 80) String claveDestino,
        boolean esDestinoPropio,
        boolean esDestinoNuevo,
        @Size(max = 200) String concepto,
        @Size(max = 20) String modoContexto,
        @Size(max = 60) String zonaHoraria) {}
