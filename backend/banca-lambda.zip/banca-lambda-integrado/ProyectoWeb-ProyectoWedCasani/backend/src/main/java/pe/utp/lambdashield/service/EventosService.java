package pe.utp.lambdashield.service;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/** Empuja los registros nuevos a las pestañas de Lambda Shield abiertas (Server-Sent Events). */
@Service
public class EventosService {

    private final List<SseEmitter> emisores = new CopyOnWriteArrayList<>();

    public SseEmitter suscribir() {
        SseEmitter emisor = new SseEmitter(0L); // sin tiempo límite
        emisores.add(emisor);
        emisor.onCompletion(() -> emisores.remove(emisor));
        emisor.onTimeout(() -> emisores.remove(emisor));
        emisor.onError(e -> emisores.remove(emisor));
        try {
            emisor.send(SseEmitter.event().name("conectado").data("ok"));
        } catch (IOException e) {
            emisores.remove(emisor);
        }
        return emisor;
    }

    public void publicar(String nombre, Object dato) {
        for (SseEmitter emisor : emisores) {
            try {
                emisor.send(SseEmitter.event().name(nombre).data(dato, MediaType.APPLICATION_JSON));
            } catch (Exception e) {
                emisores.remove(emisor);
            }
        }
    }
}
