// =====================================================================
// Conector UTP Banca  →  Lambda Shield (API Spring Boot)
// ---------------------------------------------------------------------
// Cada transferencia se envía a POST /api/transferencias/evaluar. El servidor
// la evalúa con el motor de fraude, la guarda en la base de datos y la muestra
// en Transacciones (Lambda Shield) en tiempo real.
//
// Si abres esta página desde el propio servidor Spring Boot (puerto 8080) no
// hay nada que configurar. Desde otro servidor (p. ej. Live Server) usa
// window.LAMBDA_API_BASE para indicar la dirección del API.
// =====================================================================
const LambdaShield = (() => {
  const API_BASE = window.LAMBDA_API_BASE || (location.port === '8080' ? '' : 'http://localhost:8080');
  const RUTA_TRANSACCIONES = API_BASE + '/ProyectoWeb-ProyectoWedCasani/frontend/html/transacciones.html';
  const TIEMPO_MAX_MS = 8000;

  /**
   * Evalúa una transferencia y la registra en Lambda Shield.
   * @param {Object} d { usuario, nombre, monto, cuentaOrigen, destino, claveDestino,
   *                     esDestinoPropio, esDestinoNuevo, concepto, modoContexto }
   * @returns {Promise<Object>} registro { id, fecha, tr, veredicto }
   * @throws  {Error} si el servidor no responde o rechaza la solicitud
   */
  async function evaluarYRegistrar(d) {
    const cuerpo = Object.assign({}, d, {
      zonaHoraria: Intl.DateTimeFormat().resolvedOptions().timeZone || ''
    });
    const control = new AbortController();
    const temporizador = setTimeout(() => control.abort(), TIEMPO_MAX_MS);
    try {
      const res = await fetch(API_BASE + '/api/transferencias/evaluar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(cuerpo),
        signal: control.signal
      });
      if (!res.ok) throw new Error('Lambda Shield respondió HTTP ' + res.status);
      return await res.json();
    } finally {
      clearTimeout(temporizador);
    }
  }

  return { evaluarYRegistrar, RUTA_TRANSACCIONES };
})();
