// =====================================================================
// UTP Banca — demo académica sin backend real.
// Todas las cuentas, saldos y movimientos viven en sessionStorage,
// por lo que se "resetean" cada vez que se cierra la pestaña.
// =====================================================================

// ===== Base de usuarios de prueba =====
const USUARIOS_DEMO = {
  demo: {
    clave: '1234',
    nombre: 'Reed Casani',
    cuentas: [
      { id: 'aho4821', tipo: 'Cuenta de ahorros', numero: '****4821', saldo: 4230.50 },
      { id: 'cta7710', tipo: 'Cuenta corriente',  numero: '****7710', saldo: 1050.00 }
    ],
    contactos: [
      { nombre: 'María López',        numero: '****9012', banco: 'BCP' },
      { nombre: 'Juan Pérez',         numero: '****3345', banco: 'Interbank' },
      { nombre: 'Estudio Contable JS',numero: '****5566', banco: 'UTP Banca' }
    ],
    movimientos: [
      { tipo: 'egreso',  desc: 'Luz del Sur',                 fecha: 'Hoy, 08:14 a. m.',  monto: 85.40 },
      { tipo: 'ingreso', desc: 'Transferencia de J. Pérez',    fecha: 'Ayer, 6:32 p. m.',  monto: 300.00 },
      { tipo: 'egreso',  desc: 'Plaza Vea',                    fecha: 'Ayer, 1:05 p. m.',  monto: 64.90 }
    ]
  },
  maria: {
    clave: '1234',
    nombre: 'María López',
    cuentas: [
      { id: 'aho9012', tipo: 'Cuenta de ahorros', numero: '****9012', saldo: 2870.00 },
      { id: 'cta2200', tipo: 'Cuenta corriente',  numero: '****2200', saldo: 640.25 }
    ],
    contactos: [
      { nombre: 'Reed Casani', numero: '****4821', banco: 'UTP Banca' },
      { nombre: 'Juan Pérez',  numero: '****3345', banco: 'Interbank' }
    ],
    movimientos: [
      { tipo: 'egreso',  desc: 'Claro Perú',       fecha: 'Hoy, 09:02 a. m.', monto: 59.90 },
      { tipo: 'ingreso', desc: 'Depósito en línea', fecha: 'Ayer, 3:10 p. m.', monto: 500.00 }
    ]
  },
  juan: {
    clave: '1234',
    nombre: 'Juan Pérez',
    cuentas: [
      { id: 'aho3345', tipo: 'Cuenta de ahorros', numero: '****3345', saldo: 980.75 }
    ],
    contactos: [
      { nombre: 'Reed Casani', numero: '****4821', banco: 'UTP Banca' },
      { nombre: 'María López', numero: '****9012', banco: 'BCP' }
    ],
    movimientos: [
      { tipo: 'egreso', desc: 'Pago de alquiler', fecha: 'Hoy, 07:40 a. m.', monto: 350.00 }
    ]
  }
};

const CLAVE_SESION = 'utpBancaSesion';       // guarda el usuario logueado
const PREFIJO_ESTADO = 'utpBancaEstado_';    // guarda cuentas/saldos/movimientos por usuario

// ===== Referencias principales (pueden no existir en todas las páginas) =====
const vistaLogin = document.getElementById('vista-login');
const vistaApp = document.getElementById('vista-app');
const formLogin = document.getElementById('form-login');
const alertaLogin = document.getElementById('alerta-login');
const btnSalir = document.getElementById('btn-salir');
const toastEl = document.getElementById('toast-app');
const toastMensaje = document.getElementById('toast-mensaje');
const toast = toastEl ? new bootstrap.Toast(toastEl, { delay: 2500 }) : null;

function mostrarToast(msg){
  if(!toast) return;
  toastMensaje.textContent = msg;
  toast.show();
}

function mostrarErrorLogin(msg){
  if(!alertaLogin) return;
  alertaLogin.textContent = msg;
  alertaLogin.classList.remove('d-none');
}

function ocultarErrorLogin(){
  if(!alertaLogin) return;
  alertaLogin.classList.add('d-none');
}

// ===== Estado del usuario activo (persistido en sessionStorage) =====
function obtenerUsuarioActivo(){
  return sessionStorage.getItem(CLAVE_SESION);
}

function obtenerEstado(){
  const usuario = obtenerUsuarioActivo();
  if(!usuario || !USUARIOS_DEMO[usuario]) return null;
  const guardado = sessionStorage.getItem(PREFIJO_ESTADO + usuario);
  if(guardado) return JSON.parse(guardado);
  // Primera vez en esta sesión: clonamos los datos base del usuario.
  return JSON.parse(JSON.stringify(USUARIOS_DEMO[usuario]));
}

function guardarEstado(estado){
  const usuario = obtenerUsuarioActivo();
  if(!usuario) return;
  sessionStorage.setItem(PREFIJO_ESTADO + usuario, JSON.stringify(estado));
}

function formatoMonto(n){
  return 'S/ ' + n.toLocaleString('es-PE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// ===== Login con validación contra varios usuarios de prueba =====
if(formLogin){
  formLogin.addEventListener('submit', function(e){
    e.preventDefault();
    ocultarErrorLogin();

    const usuario = document.getElementById('usuario').value.trim().toLowerCase();
    const clave = document.getElementById('clave').value.trim();
    const registro = USUARIOS_DEMO[usuario];

    if(registro && registro.clave === clave){
      sessionStorage.setItem(CLAVE_SESION, usuario);
      vistaLogin.style.display = 'none';
      vistaApp.style.display = 'block';
      iniciarContadorSesion();
      pintarDashboard();
      mostrarToast(`Bienvenido, ${registro.nombre.split(' ')[0]}. Sesión iniciada correctamente.`);
    } else {
      mostrarErrorLogin('Usuario o clave incorrectos. Verifica tus datos e intenta de nuevo.');
    }
  });
}

// ===== Guardia de sesión para páginas internas (transferencias, pagos, etc.) =====
// Si la página no tiene el formulario de login (es una página interna) y no hay
// sesión activa guardada, no se puede ver el contenido: se redirige al login.
if(!formLogin && document.getElementById('contador-sesion') && !obtenerUsuarioActivo()){
  window.location.href = 'index.html';
}

// ===== Cerrar sesión =====
if(btnSalir){
  btnSalir.addEventListener('click', function(){
    clearInterval(temporizador);
    sessionStorage.removeItem(CLAVE_SESION);

    if(vistaLogin && vistaApp){
      // En index.html: volver a la pantalla de login sin cambiar de página
      vistaApp.style.display = 'none';
      vistaLogin.style.display = 'flex';
      const claveInput = document.getElementById('clave');
      if(claveInput) claveInput.value = '';
      mostrarToast('Sesión cerrada por seguridad.');
    } else {
      // En las demás páginas: regresar al inicio (login)
      window.location.href = 'index.html';
    }
  });
}

// ===== Panel principal (index.html) — personalizado según el usuario =====
const elSaludoNombre = document.getElementById('saludo-nombre');
const elMontoSaldo = document.getElementById('monto-saldo');
const elEtiquetaCuenta = document.getElementById('etiqueta-cuenta-principal');
const elEtiquetaTitular = document.getElementById('etiqueta-titular');
const elListaMovimientos = document.getElementById('lista-movimientos');

let saldoVisible = true;

function iconoMovimiento(tipo){
  return tipo === 'ingreso'
    ? '<div class="mov-icono ingreso"><i class="fa-solid fa-arrow-down"></i></div>'
    : '<div class="mov-icono egreso"><i class="fa-solid fa-bolt"></i></div>';
}

function pintarDashboard(){
  const estado = obtenerEstado();
  if(!estado || !elMontoSaldo) return;

  const cuentaPrincipal = estado.cuentas[0];

  if(elSaludoNombre) elSaludoNombre.textContent = estado.nombre.split(' ')[0];
  if(elEtiquetaCuenta) elEtiquetaCuenta.textContent = `${cuentaPrincipal.tipo} · ${cuentaPrincipal.numero}`;
  if(elEtiquetaTitular) elEtiquetaTitular.textContent = `${estado.nombre.toUpperCase()} · Débito UTP`;

  elMontoSaldo.dataset.saldoReal = formatoMonto(cuentaPrincipal.saldo);
  elMontoSaldo.textContent = saldoVisible ? elMontoSaldo.dataset.saldoReal : 'S/ • • • • •';

  if(elListaMovimientos){
    elListaMovimientos.innerHTML = estado.movimientos.map(m => `
      <div class="movimiento">
        ${iconoMovimiento(m.tipo)}
        <div class="flex-grow-1">
          <div class="fw-semibold" style="font-size:.9rem;">${m.desc}</div>
          <div class="text-muted" style="font-size:.75rem;">${m.fecha}</div>
        </div>
        <div class="fw-semibold" style="color:${m.tipo === 'ingreso' ? '#1E8F5A' : 'var(--utp-maroon)'};">
          ${m.tipo === 'ingreso' ? '+' : '-'} ${formatoMonto(m.monto)}
        </div>
      </div>`).join('');
  }
}

if(elMontoSaldo) pintarDashboard();

// ===== Ocultar / mostrar saldo (privacidad en espacios públicos) =====
const btnOcultarSaldo = document.getElementById('btn-ocultar-saldo');
const textoOcultar = document.getElementById('texto-ocultar');
if(btnOcultarSaldo){
  btnOcultarSaldo.addEventListener('click', function(){
    saldoVisible = !saldoVisible;
    elMontoSaldo.textContent = saldoVisible ? elMontoSaldo.dataset.saldoReal : 'S/ • • • • •';
    textoOcultar.textContent = saldoVisible ? 'Ocultar saldo' : 'Mostrar saldo';
  });
}

// ===== Transferencias: cuenta propia, contacto o cuenta externa =====
const formTransferencia = document.getElementById('form-transferencia');
const selectOrigen = document.getElementById('select-origen');
const selectDestino = document.getElementById('select-destino');
const inputMonto = document.getElementById('input-monto');
const inputConcepto = document.getElementById('input-concepto');
const wrapDestinoManual = document.getElementById('wrap-destino-manual');
const inputDestinoManual = document.getElementById('input-destino-manual');
const alertaTransferencia = document.getElementById('alerta-transferencia');
const listaContactos = document.getElementById('lista-contactos');

function mostrarErrorTransferencia(msg){
  if(!alertaTransferencia) return;
  alertaTransferencia.textContent = msg;
  alertaTransferencia.classList.remove('d-none');
}
function ocultarErrorTransferencia(){
  if(!alertaTransferencia) return;
  alertaTransferencia.classList.add('d-none');
}

function pintarFormularioTransferencia(){
  const estado = obtenerEstado();
  if(!estado || !selectOrigen) return;

  // --- Cuenta de origen: siempre las cuentas propias, con saldo actualizado ---
  selectOrigen.innerHTML = estado.cuentas.map(c =>
    `<option value="${c.id}">${c.tipo} · ${c.numero} (${formatoMonto(c.saldo)})</option>`
  ).join('');

  // --- Destinatario: mis otras cuentas + contactos frecuentes + otra cuenta ---
  let opcionesDestino = '';
  if(estado.cuentas.length > 1){
    opcionesDestino += `<optgroup label="Mis cuentas">` + estado.cuentas.map(c =>
      `<option value="own:${c.id}">${c.tipo} · ${c.numero}</option>`
    ).join('') + `</optgroup>`;
  }
  if(estado.contactos.length){
    opcionesDestino += `<optgroup label="Contactos frecuentes">` + estado.contactos.map((c, i) =>
      `<option value="contact:${i}">${c.nombre} · ${c.numero}</option>`
    ).join('') + `</optgroup>`;
  }
  opcionesDestino += `<option value="otra">Otra cuenta…</option>`;
  selectDestino.innerHTML = opcionesDestino;

  // --- Contactos frecuentes (tarjeta lateral) ---
  if(listaContactos){
    listaContactos.innerHTML = estado.contactos.map(c => `
      <div class="movimiento">
        <div class="mov-icono ingreso"><i class="fa-solid fa-user"></i></div>
        <div class="flex-grow-1">
          <div class="fw-semibold" style="font-size:.9rem;">${c.nombre}</div>
          <div class="text-muted" style="font-size:.75rem;">${c.numero} · ${c.banco}</div>
        </div>
      </div>`).join('');
  }
}


// ===== Resultado de la evaluación de Lambda Shield =====
const NIVELES_LS = {
  bajo:    { texto: 'Riesgo bajo · Aprobada',        clase: 'alert-success' },
  medio:   { texto: 'Riesgo medio · En monitoreo',   clase: 'alert-info' },
  alto:    { texto: 'Riesgo alto · Revisión manual', clase: 'alert-warning' },
  critico: { texto: 'Riesgo crítico · Bloqueada',    clase: 'alert-danger' }
};
function pintarResultadoLambda(registro){
  const el = document.getElementById('resultado-lambda');
  if(!el) return;
  const meta = NIVELES_LS[registro.veredicto.nivel];
  el.className = 'alert py-2 px-3 small mt-3 ' + meta.clase;
  el.textContent = '';
  const titulo = document.createElement('strong');
  titulo.textContent = 'Lambda Shield: ' + meta.texto;
  const detalle = document.createElement('span');
  detalle.textContent = ` · Puntaje ${registro.veredicto.puntaje}/100 · Registro ${registro.id} `;
  const enlace = document.createElement('a');
  enlace.href = LambdaShield.RUTA_TRANSACCIONES;
  enlace.target = '_blank';
  enlace.rel = 'noopener';
  enlace.textContent = 'Ver en Lambda Shield';
  el.append(titulo, detalle, enlace);
}

if(selectOrigen) pintarFormularioTransferencia();

if(selectDestino && wrapDestinoManual){
  selectDestino.addEventListener('change', function(){
    wrapDestinoManual.classList.toggle('d-none', this.value !== 'otra');
  });
}

if(formTransferencia){
  formTransferencia.addEventListener('submit', async function(e){
    e.preventDefault();
    ocultarErrorTransferencia();

    const estado = obtenerEstado();
    const origenId = selectOrigen.value;
    const origen = estado.cuentas.find(c => c.id === origenId);
    const monto = parseFloat(inputMonto.value);
    const concepto = inputConcepto.value.trim();
    const destinoVal = selectDestino.value;

    if(!monto || monto <= 0){
      mostrarErrorTransferencia('Ingresa un monto válido, mayor a S/ 0.00.');
      return;
    }
    if(monto > origen.saldo){
      mostrarErrorTransferencia(`Saldo insuficiente. Tu ${origen.tipo} ${origen.numero} tiene ${formatoMonto(origen.saldo)} disponibles.`);
      return;
    }

    let descripcionDestino = '';
    let cuentaDestinoPropia = null;
    let claveDestino = '';
    let esDestinoNuevo = false;

    if(destinoVal.startsWith('own:')){
      const destinoId = destinoVal.replace('own:', '');
      if(destinoId === origenId){
        mostrarErrorTransferencia('La cuenta de destino no puede ser igual a la cuenta de origen.');
        return;
      }
      cuentaDestinoPropia = estado.cuentas.find(c => c.id === destinoId);
      descripcionDestino = `${cuentaDestinoPropia.tipo} · ${cuentaDestinoPropia.numero} (tú mismo)`;
      claveDestino = 'own:' + destinoId;
    } else if(destinoVal.startsWith('contact:')){
      const idx = Number(destinoVal.replace('contact:', ''));
      descripcionDestino = estado.contactos[idx].nombre;
      claveDestino = 'contact:' + estado.contactos[idx].numero;
    } else {
      const numeroManual = inputDestinoManual ? inputDestinoManual.value.trim() : '';
      if(!numeroManual){
        mostrarErrorTransferencia('Ingresa el número de cuenta de destino.');
        return;
      }
      descripcionDestino = `cuenta ${numeroManual}`;
      claveDestino = 'cuenta:' + numeroManual;
      esDestinoNuevo = true;
    }

    if(!confirm(`¿Confirmas transferir ${formatoMonto(monto)} desde tu ${origen.tipo} ${origen.numero} hacia ${descripcionDestino}? Esta acción no se puede deshacer.`)){
      return;
    }

    // --- Lambda Shield: se evalúa el riesgo ANTES de mover el dinero ---
    const btnEnviar = formTransferencia.querySelector('button[type="submit"]');
    const selContexto = document.getElementById('select-contexto-demo');
    if(btnEnviar) btnEnviar.disabled = true;
    let registroLS;
    try {
      registroLS = await LambdaShield.evaluarYRegistrar({
        usuario: obtenerUsuarioActivo(),
        nombre: estado.nombre,
        monto: monto,
        cuentaOrigen: `${origen.tipo} ${origen.numero}`,
        destino: descripcionDestino,
        claveDestino: claveDestino,
        esDestinoPropio: !!cuentaDestinoPropia,
        esDestinoNuevo: esDestinoNuevo,
        concepto: concepto,
        modoContexto: selContexto ? selContexto.value : 'normal'
      });
    } catch(err){
      console.error('Lambda Shield:', err);
      mostrarErrorTransferencia('No se pudo verificar la operación con el sistema antifraude. No se realizó la transferencia; intenta nuevamente.');
      return;
    } finally {
      if(btnEnviar) btnEnviar.disabled = false;
    }

    if(registroLS && registroLS.veredicto.bloqueada){
      pintarResultadoLambda(registroLS);
      mostrarErrorTransferencia(`Operación bloqueada por Lambda Shield (${registroLS.id}, puntaje ${registroLS.veredicto.puntaje}). No se movió dinero. Contacta a soporte si la reconoces.`);
      return;
    }

    // --- Se aplica el movimiento de dinero ---
    origen.saldo -= monto;
    if(cuentaDestinoPropia) cuentaDestinoPropia.saldo += monto;

    estado.movimientos.unshift({
      tipo: 'egreso',
      desc: concepto ? `Transferencia a ${descripcionDestino} · ${concepto}` : `Transferencia a ${descripcionDestino}`,
      fecha: 'Hoy, ahora',
      monto: monto
    });
    if(cuentaDestinoPropia){
      estado.movimientos.unshift({
        tipo: 'ingreso',
        desc: `Transferencia recibida de ${origen.tipo} ${origen.numero}`,
        fecha: 'Hoy, ahora',
        monto: monto
      });
    }

    guardarEstado(estado);
    pintarFormularioTransferencia();
    if(wrapDestinoManual) wrapDestinoManual.classList.add('d-none');
    this.reset();

    if(registroLS) pintarResultadoLambda(registroLS);
    mostrarToast(`Transferencia enviada. Nuevo saldo en ${origen.tipo} ${origen.numero}: ${formatoMonto(origen.saldo)}`);
  });
}

// ===== Confirmación de pago de servicio =====
const formPago = document.getElementById('form-pago');
if(formPago){
  formPago.addEventListener('submit', function(e){
    e.preventDefault();
    if(confirm('¿Confirmas el pago de este servicio? Esta acción no se puede deshacer.')){
      mostrarToast('Pago realizado con éxito.');
      this.reset();
    }
  });
}

// ===== Bloqueo / desbloqueo de tarjeta =====
const switchBloqueo = document.getElementById('switch-bloqueo-tarjeta');
if(switchBloqueo){
  switchBloqueo.addEventListener('change', function(){
    mostrarToast(this.checked ? 'Tarjeta bloqueada temporalmente.' : 'Tarjeta desbloqueada.');
  });
}

// ===== Formulario de soporte / chat =====
const formSoporte = document.getElementById('form-soporte');
if(formSoporte){
  formSoporte.addEventListener('submit', function(e){
    e.preventDefault();
    mostrarToast('Mensaje enviado. Un asesor te responderá pronto.');
    this.reset();
  });
}

// ===== Timeout de sesión por inactividad (seguridad) =====
let temporizador;
function iniciarContadorSesion(){
  let segundos = 300; // 5 minutos
  const contadorEl = document.getElementById('contador-sesion');
  if(!contadorEl) return;
  clearInterval(temporizador);
  temporizador = setInterval(function(){
    segundos--;
    const m = String(Math.floor(segundos/60)).padStart(2,'0');
    const s = String(segundos%60).padStart(2,'0');
    contadorEl.textContent = `${m}:${s}`;
    if(segundos <= 0){
      clearInterval(temporizador);
      sessionStorage.removeItem(CLAVE_SESION);
      mostrarToast('Tu sesión expiró por inactividad.');
      setTimeout(() => { window.location.href = 'index.html'; }, 1200);
    }
  }, 1000);
}

// En páginas internas (sin formulario de login) inicia el contador al cargar,
// ya que si llegamos hasta aquí es porque la sesión ya fue validada.
if(document.getElementById('contador-sesion') && !formLogin){
  iniciarContadorSesion();
}

// Reinicia el contador ante actividad del usuario
['click','keydown','touchstart'].forEach(evt => {
  document.addEventListener(evt, function(){
    const appVisible = vistaApp ? vistaApp.style.display === 'block' : true;
    if(appVisible) iniciarContadorSesion();
  });
});

// Si ya existe una sesión activa y estamos en index.html, mostrar el
// dashboard directamente en vez de pedir el login de nuevo.
if(vistaLogin && vistaApp && obtenerUsuarioActivo()){
  vistaLogin.style.display = 'none';
  vistaApp.style.display = 'block';
  iniciarContadorSesion();
  pintarDashboard();
}

// ===== Detección de modo sin conexión (funcionalidad offline parcial) =====
window.addEventListener('offline', () => document.body.classList.add('modo-offline'));
window.addEventListener('online', () => document.body.classList.remove('modo-offline'));
